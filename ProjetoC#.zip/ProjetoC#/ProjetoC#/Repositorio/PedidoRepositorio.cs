﻿using Microsoft.EntityFrameworkCore;
using ProjetoC_.Data;
using ProjetoC_.Models;
using ProjetoC_.Repositorio.Interfaces;

namespace ProjetoC_.Repositorio
{
    public class PedidoRepositorio : IPedidoRepositorio
    {
        private readonly ProjetoDbContext _dbContext;

        public PedidoRepositorio(ProjetoDbContext ProjetoDbContext)
        {
            _dbContext = ProjetoDbContext;
        }

        public async Task<PedidosModel> BuscarPorId(int id)
        {
            return await _dbContext.Pedidos.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<PedidosModel>> BuscaTodos()
        {
            return await _dbContext.Pedidos.ToListAsync();
        }
        public async Task<PedidosModel> Adicionar(PedidosModel pedido)
        {
            await _dbContext.Pedidos.AddAsync(pedido);
            await _dbContext.SaveChangesAsync();

            return pedido;
        }

        public async Task<bool> Apagar(int id)
        {
            PedidosModel pedidoPorId = await BuscarPorId(id);


            if (pedidoPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            _dbContext.Pedidos.Remove(pedidoPorId);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<PedidosModel> Atualizar(PedidosModel pedido, int id)
        {
            PedidosModel pedidoPorId = await BuscarPorId(id);


            if (pedidoPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            pedidoPorId.usuarioId = pedido.usuarioId;
            pedidoPorId.EnderecoEntrega = pedido.EnderecoEntrega;

            _dbContext.Pedidos.Update(pedidoPorId);
            await _dbContext.SaveChangesAsync();

            return pedidoPorId;
        }

    }
}

