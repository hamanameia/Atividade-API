﻿using Microsoft.EntityFrameworkCore;
using ProjetoC_.Data;
using ProjetoC_.Models;
using ProjetoC_.Repositorio.Interfaces;

namespace ProjetoC_.Repositorio
{
    public class UsuarioRepositorio : IUsuarioRepositorio
    {
        private readonly ProjetoDbContext _dbContext;

        public UsuarioRepositorio(ProjetoDbContext ProjetoDbContext)
        {
            _dbContext = ProjetoDbContext;
        }

        public async Task<UsuariosModel> BuscarPorId(int id)
        {
            return await _dbContext.Usuarios.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<UsuariosModel>> BuscaTodos()
        {
            return await _dbContext.Usuarios.ToListAsync();
        }
        public async Task<UsuariosModel> Adicionar(UsuariosModel usuario)
        {
            await _dbContext.Usuarios.AddAsync(usuario);
            await _dbContext.SaveChangesAsync();

            return usuario;
        }

        public async Task<bool> Apagar(int id)
        {
            UsuariosModel usuarioPorId = await BuscarPorId(id);


            if (usuarioPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            _dbContext.Usuarios.Remove(usuarioPorId);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<UsuariosModel> Atualizar(UsuariosModel usuario, int id)
        {
            UsuariosModel usuarioPorId = await BuscarPorId(id);


            if (usuarioPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            usuarioPorId.Nome = usuario.Nome;
            usuarioPorId.Email = usuario.Email;

            _dbContext.Usuarios.Update(usuarioPorId);
            await _dbContext.SaveChangesAsync();

            return usuarioPorId;
        }

    }
}
