﻿using ProjetoC_.Models;

namespace ProjetoC_.Repositorio.Interfaces
{
    public interface ICategoriaRepositorio
    {
        Task<List<CategoriasModel>> BuscaTodos();

        Task<CategoriasModel> BuscarPorId(int id);
        Task<CategoriasModel> Adicionar(CategoriasModel categoria);
        Task<CategoriasModel> Atualizar(CategoriasModel categoria, int id);
        Task<bool> Apagar(int id);
    }
}
