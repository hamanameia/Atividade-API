﻿namespace ProjetoC_.Models
{
    public class PedidosModel
    {
        public int Id { get; set; }
        public int usuarioId { get; set; }
        public string EnderecoEntrega { get; set; }

        public virtual UsuariosModel? Usuarios { get; set; }
    }
}
