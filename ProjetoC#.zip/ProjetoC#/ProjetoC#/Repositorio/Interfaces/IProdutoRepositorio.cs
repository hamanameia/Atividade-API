﻿using ProjetoC_.Models;

namespace ProjetoC_.Repositorio.Interfaces
{
    public interface IProdutoRepositorio
    {
        Task<List<ProdutosModel>> BuscaTodos();

        Task<ProdutosModel> BuscarPorId(int id);
        Task<ProdutosModel> Adicionar(ProdutosModel produtos);
        Task<ProdutosModel> Atualizar(ProdutosModel produtos, int id);
        Task<bool> Apagar(int id);
    }
}
