﻿using Microsoft.AspNetCore.Mvc;
using ProjetoC_.Models;
using ProjetoC_.Repositorio.Interfaces;

namespace ProjetoC_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProdutosController :ControllerBase
    {
        private readonly IProdutoRepositorio _produtosRepositorios;

    public ProdutosController(IProdutoRepositorio produtosRepositorios)
    {
        _produtosRepositorios = produtosRepositorios;
    }

    [HttpGet]
    public async Task<ActionResult<List<ProdutosModel>>> BuscaTodos()
    {
        List<ProdutosModel> produtos = await _produtosRepositorios.BuscaTodos();
        return Ok(produtos);
    }
    [HttpGet("{id}")]

    public async Task<ActionResult<ProdutosModel>> BuscarPorId(int id)
    {
        ProdutosModel produto = await _produtosRepositorios.BuscarPorId(id);
        return Ok(produto);
    }
    [HttpPost]

    public async Task<ActionResult<ProdutosModel>> Adicionar([FromBody] ProdutosModel produtoModel)
    {
        ProdutosModel produto = await _produtosRepositorios.Adicionar(produtoModel);
        return Ok(produto);
    }
    [HttpPut("{id}")]

    public async Task<ActionResult<ProdutosModel>> Atualizar(int id, [FromBody] ProdutosModel produtoModel)
    {
        produtoModel.Id = id;
        ProdutosModel produto = await _produtosRepositorios.Atualizar(produtoModel, id);
        return Ok(produto);
    }
    [HttpDelete("{id}")]

    public async Task<ActionResult<ProdutosModel>> Apagar(int id)
    {
        bool apagado = await _produtosRepositorios.Apagar(id);
        return Ok(apagado);
    }
}
}
