﻿using ProjetoC_.Models;

namespace ProjetoC_.Repositorio.Interfaces
{
    public interface IUsuarioRepositorio
    {
        Task<List<UsuariosModel>> BuscaTodos();

        Task<UsuariosModel> BuscarPorId(int id);
        Task<UsuariosModel> Adicionar(UsuariosModel usuario);
        Task<UsuariosModel> Atualizar(UsuariosModel usuario, int id);
        Task<bool> Apagar(int id);

    }
}
