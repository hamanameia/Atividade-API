﻿namespace ProjetoC_.Models
{
    public class ProdutosModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Descrição { get; set; }
        public Decimal Preco { get; set; }
    }
}
