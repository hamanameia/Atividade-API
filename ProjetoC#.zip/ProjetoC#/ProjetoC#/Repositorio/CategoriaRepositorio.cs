﻿using Microsoft.EntityFrameworkCore;
using ProjetoC_.Data;
using ProjetoC_.Models;
using ProjetoC_.Repositorio.Interfaces;

namespace ProjetoC_.Repositorio
{
    public class CategoriaRepositorio : ICategoriaRepositorio
    {
        private readonly ProjetoDbContext _dbContext;

        public CategoriaRepositorio(ProjetoDbContext ProjetoDbContext)
        {
            _dbContext = ProjetoDbContext;
        }

        public async Task<CategoriasModel> BuscarPorId(int id)
        {
            return await _dbContext.Categorias.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<CategoriasModel>> BuscaTodos()
        {
            return await _dbContext.Categorias.ToListAsync();
        }
        public async Task<CategoriasModel> Adicionar(CategoriasModel categoria)
        {
            await _dbContext.Categorias.AddAsync(categoria);
            await _dbContext.SaveChangesAsync();

            return categoria;
        }

        public async Task<bool> Apagar(int id)
        {
            CategoriasModel categoriaPorId = await BuscarPorId(id);


            if (categoriaPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            _dbContext.Categorias.Remove(categoriaPorId);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<CategoriasModel> Atualizar(CategoriasModel categoria, int id)
        {
            CategoriasModel categoriaPorId = await BuscarPorId(id);


            if (categoriaPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            categoriaPorId.Nome = categoria.Nome;
            categoriaPorId.Status = categoria.Status;

            _dbContext.Categorias.Update(categoriaPorId);
            await _dbContext.SaveChangesAsync();

            return categoriaPorId;
        }

    }
}
