﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using ProjetoC_.Models;

namespace ProjetoC_.Data.Map
{
    public class PedidoMap : IEntityTypeConfiguration<PedidosModel>
    {
        public void Configure(EntityTypeBuilder<PedidosModel> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.usuarioId).IsRequired();
            builder.Property(x => x.EnderecoEntrega).IsRequired().HasMaxLength(255);
        }
    }
}
