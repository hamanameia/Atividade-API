﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ProjetoC_.Models
{
    public class UsuariosModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public DateOnly DataNascimento { get; set; }

    }
}
