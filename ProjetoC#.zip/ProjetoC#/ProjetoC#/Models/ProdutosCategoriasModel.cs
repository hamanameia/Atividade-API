﻿namespace ProjetoC_.Models
{
    public class ProdutosCategoriasModel
    {
        public int Id { get; set; }
        public int ProdutoId { get; set; }
        public int CategoriaId { get; set; }
        public virtual ProdutosModel? Produtos { get; set; }
        public virtual CategoriasModel? Categorias { get; set; }

    }
}
