﻿using Microsoft.EntityFrameworkCore;
using ProjetoC_.Data;
using ProjetoC_.Models;
using ProjetoC_.Repositorio.Interfaces;

namespace ProjetoC_.Repositorio
{
    public class ProdutoRepositorio : IProdutoRepositorio
    {
        private readonly ProjetoDbContext _dbContext;

        public ProdutoRepositorio(ProjetoDbContext ProjetoDbContext)
        {
            _dbContext = ProjetoDbContext;
        }

        public async Task<ProdutosModel> BuscarPorId(int id)
        {
            return await _dbContext.Produtos.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<ProdutosModel>> BuscaTodos()
        {
            return await _dbContext.Produtos.ToListAsync();
        }
        public async Task<ProdutosModel> Adicionar(ProdutosModel produto)
        {
            await _dbContext.Produtos.AddAsync(produto);
            await _dbContext.SaveChangesAsync();

            return produto;
        }

        public async Task<bool> Apagar(int id)
        {
            ProdutosModel produtoPorId = await BuscarPorId(id);


            if (produtoPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            _dbContext.Produtos.Remove(produtoPorId);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<ProdutosModel> Atualizar(ProdutosModel produto, int id)
        {
            ProdutosModel produtoPorId = await BuscarPorId(id);


            if (produtoPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            produtoPorId.Nome = produto.Nome;
            produtoPorId.Descrição = produto.Descrição;
            produtoPorId.Preco = produto.Preco;


            _dbContext.Produtos.Update(produtoPorId);
            await _dbContext.SaveChangesAsync();

            return produtoPorId;
        }

    }
}
