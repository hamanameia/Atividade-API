﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjetoC_.Migrations
{
    /// <inheritdoc />
    public partial class EsperoQueFinal : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProdutosCategorias_Categorias_CategoriasId",
                table: "ProdutosCategorias");

            migrationBuilder.DropForeignKey(
                name: "FK_ProdutosCategorias_Produtos_ProdutosId",
                table: "ProdutosCategorias");

            migrationBuilder.AlterColumn<int>(
                name: "ProdutosId",
                table: "ProdutosCategorias",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<int>(
                name: "CategoriasId",
                table: "ProdutosCategorias",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_ProdutosCategorias_Categorias_CategoriasId",
                table: "ProdutosCategorias",
                column: "CategoriasId",
                principalTable: "Categorias",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ProdutosCategorias_Produtos_ProdutosId",
                table: "ProdutosCategorias",
                column: "ProdutosId",
                principalTable: "Produtos",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProdutosCategorias_Categorias_CategoriasId",
                table: "ProdutosCategorias");

            migrationBuilder.DropForeignKey(
                name: "FK_ProdutosCategorias_Produtos_ProdutosId",
                table: "ProdutosCategorias");

            migrationBuilder.AlterColumn<int>(
                name: "ProdutosId",
                table: "ProdutosCategorias",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CategoriasId",
                table: "ProdutosCategorias",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_ProdutosCategorias_Categorias_CategoriasId",
                table: "ProdutosCategorias",
                column: "CategoriasId",
                principalTable: "Categorias",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ProdutosCategorias_Produtos_ProdutosId",
                table: "ProdutosCategorias",
                column: "ProdutosId",
                principalTable: "Produtos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
