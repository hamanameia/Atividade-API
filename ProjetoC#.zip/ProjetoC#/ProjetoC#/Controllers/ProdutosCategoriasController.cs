﻿using Microsoft.AspNetCore.Mvc;
using ProjetoC_.Models;
using ProjetoC_.Repositorio.Interfaces;

namespace ProjetoC_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProdutosCategoriasController : ControllerBase
    {
        private readonly IProdutoCategoriaRepositorio _produtoscategoriasRepositorios;

        public ProdutosCategoriasController(IProdutoCategoriaRepositorio produtoscategoriasRepositorios)
        {
            _produtoscategoriasRepositorios = produtoscategoriasRepositorios;
        }

        [HttpGet]
        public async Task<ActionResult<List<ProdutosCategoriasModel>>> BuscaTodos()
        {
            List<ProdutosCategoriasModel> produtoscategorias = await _produtoscategoriasRepositorios.BuscaTodos();
            return Ok(produtoscategorias);
        }
        [HttpGet("{id}")]

        public async Task<ActionResult<ProdutosCategoriasModel>> BuscarPorId(int id)
        {
            ProdutosCategoriasModel produto = await _produtoscategoriasRepositorios.BuscarPorId(id);
            return Ok(produto);
        }
        [HttpPost]

        public async Task<ActionResult<ProdutosCategoriasModel>> Adicionar([FromBody] ProdutosCategoriasModel produtoModel)
        {
            ProdutosCategoriasModel produto = await _produtoscategoriasRepositorios.Adicionar(produtoModel);
            return Ok(produto);
        }
        [HttpPut("{id}")]

        public async Task<ActionResult<ProdutosCategoriasModel>> Atualizar(int id, [FromBody] ProdutosCategoriasModel produtoModel)
        {
            produtoModel.Id = id;
            ProdutosCategoriasModel produto = await _produtoscategoriasRepositorios.Atualizar(produtoModel, id);
            return Ok(produto);
        }
        [HttpDelete("{id}")]

        public async Task<ActionResult<ProdutosCategoriasModel>> Apagar(int id)
        {
            bool apagado = await _produtoscategoriasRepositorios.Apagar(id);
            return Ok(apagado);
        }
    }
}
