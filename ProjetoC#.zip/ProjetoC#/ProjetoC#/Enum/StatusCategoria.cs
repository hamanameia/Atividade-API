﻿using System.ComponentModel;

namespace ProjetoC_.Enum
{
    public enum StatusCategoria
    {
        [Description("Ativa")]
        ativa = 1,
        [Description("Inativo")]
        inativo = 2,
    }
}
