﻿using ProjetoC_.Models;

namespace ProjetoC_.Repositorio.Interfaces
{
    public interface IProdutoCategoriaRepositorio
    {
        Task<List<ProdutosCategoriasModel>> BuscaTodos();

        Task<ProdutosCategoriasModel> BuscarPorId(int id);
        Task<ProdutosCategoriasModel> Adicionar(ProdutosCategoriasModel produtocategoria);
        Task<ProdutosCategoriasModel> Atualizar(ProdutosCategoriasModel produtocategoria, int id);
        Task<bool> Apagar(int id);
    }
}
