﻿using Microsoft.EntityFrameworkCore;
using ProjetoC_.Data;
using ProjetoC_.Models;
using ProjetoC_.Repositorio.Interfaces;

namespace ProjetoC_.Repositorio
{
    public class ProdutoCategoriaRepositorio : IProdutoCategoriaRepositorio
    {
        private readonly ProjetoDbContext _dbContext;

        public ProdutoCategoriaRepositorio(ProjetoDbContext ProjetoDbContext)
        {
            _dbContext = ProjetoDbContext;
        }

        public async Task<ProdutosCategoriasModel> BuscarPorId(int id)
        {
            return await _dbContext.ProdutosCategorias.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<ProdutosCategoriasModel>> BuscaTodos()
        {
            return await _dbContext.ProdutosCategorias.ToListAsync();
        }
        public async Task<ProdutosCategoriasModel> Adicionar(ProdutosCategoriasModel produtocategoria)
        {
            await _dbContext.ProdutosCategorias.AddAsync(produtocategoria);
            await _dbContext.SaveChangesAsync();

            return produtocategoria;
        }

        public async Task<bool> Apagar(int id)
        {
            ProdutosCategoriasModel produtocategoriaPorId = await BuscarPorId(id);


            if (produtocategoriaPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            _dbContext.ProdutosCategorias.Remove(produtocategoriaPorId);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<ProdutosCategoriasModel> Atualizar(ProdutosCategoriasModel produtocategoria, int id)
        {
            ProdutosCategoriasModel produtocategoriaPorId = await BuscarPorId(id);


            if (produtocategoriaPorId == null)
            {
                throw new Exception($"Usuário do ID: {id} não foi encontrado");
            }

            produtocategoriaPorId.ProdutoId = produtocategoria.ProdutoId;
            produtocategoriaPorId.CategoriaId = produtocategoria.CategoriaId;

            _dbContext.ProdutosCategorias.Update(produtocategoriaPorId);
            await _dbContext.SaveChangesAsync();

            return produtocategoriaPorId;
        }

    }
}
