﻿using Microsoft.AspNetCore.Mvc;
using ProjetoC_.Models;
using ProjetoC_.Repositorio.Interfaces;

namespace ProjetoC_.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriaController : ControllerBase
    {
        private readonly ICategoriaRepositorio _categoriasRepositorios;

        public CategoriaController(ICategoriaRepositorio categoriasRepositorios)
        {
            _categoriasRepositorios = categoriasRepositorios;
        }

        [HttpGet]
        public async Task<ActionResult<List<CategoriasModel>>> BuscaTodos()
        {
            List<CategoriasModel> categorias = await _categoriasRepositorios.BuscaTodos();
            return Ok(categorias);
        }
        [HttpGet("{id}")]

        public async Task<ActionResult<CategoriasModel>> BuscarPorId(int id)
        {
            CategoriasModel categoria = await _categoriasRepositorios.BuscarPorId(id);
            return Ok(categoria);
        }
        [HttpPost]

        public async Task<ActionResult<CategoriasModel>> Adicionar([FromBody] CategoriasModel categoriaModel)
        {
            CategoriasModel categoria = await _categoriasRepositorios.Adicionar(categoriaModel);
            return Ok(categoria);
        }
        [HttpPut("{id}")]

        public async Task<ActionResult<CategoriasModel>> Atualizar(int id, [FromBody] CategoriasModel categoriaModel)
        {
            categoriaModel.Id = id;
            CategoriasModel categoria = await _categoriasRepositorios.Atualizar(categoriaModel, id);
            return Ok(categoria);
        }
        [HttpDelete("{id}")]

        public async Task<ActionResult<CategoriasModel>> Apagar(int id)
        {
            bool apagado = await _categoriasRepositorios.Apagar(id);
            return Ok(apagado);
        }
    }
}
