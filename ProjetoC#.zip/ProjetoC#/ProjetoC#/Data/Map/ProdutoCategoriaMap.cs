﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using ProjetoC_.Models;

namespace ProjetoC_.Data.Map
{
    public class ProdutoCategoriaMap : IEntityTypeConfiguration<ProdutosCategoriasModel>
    {
        public void Configure(EntityTypeBuilder<ProdutosCategoriasModel> builder)
        {
            builder.HasKey(x => x.Id);
            builder.Property(x => x.ProdutoId).IsRequired();
            builder.Property(x => x.CategoriaId).IsRequired();
        }
    }
}
