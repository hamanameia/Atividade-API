﻿using Microsoft.EntityFrameworkCore;
using ProjetoC_.Data.Map;
using ProjetoC_.Models;

namespace ProjetoC_.Data
{
    public class ProjetoDbContext : DbContext
    {
        public ProjetoDbContext(DbContextOptions<ProjetoDbContext> options) : base(options) { }

        public DbSet<UsuariosModel> Usuarios { get; set; }
        public DbSet<PedidosModel> Pedidos { get; set; }
        public DbSet<CategoriasModel> Categorias { get; set; }
        public DbSet<ProdutosModel> Produtos { get; set; }
        public DbSet<ProdutosCategoriasModel> ProdutosCategorias { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new UsuarioMap());
            modelBuilder.ApplyConfiguration(new PedidoMap());
            modelBuilder.ApplyConfiguration(new CategoriaMap());
            modelBuilder.ApplyConfiguration(new ProdutoMap());
            modelBuilder.ApplyConfiguration(new ProdutoCategoriaMap());

            base.OnModelCreating(modelBuilder);
        }
    }
}
